package bll;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

import dal.FamilyTreeDAOStub;
import dal.IFamilyTreeDAO;


public class FamilyTreeBOTest {

    static IFamilyTreeDAO familyTreeDao;
    static FamilyTreeBO tree;

    @BeforeAll
    static void setUp() {
        familyTreeDao = new FamilyTreeDAOStub();
        tree = new FamilyTreeBO(familyTreeDao);
    }

    @Test
    @DisplayName("Test isSibling method - Edge Coverage")
    public void testIsSiblingEdgeCoverage() {
        boolean isSiblingScenario1 = tree.isSibling(10, 11);
        assertEquals(isSiblingScenario1, "Expected to be siblings but they are not.");

        boolean isSiblingScenario2 = tree.isSibling(12, 11);
        assertFalse(isSiblingScenario2, "Expected not to be siblings.");

        boolean isSiblingScenario3 = tree.isSibling(10, 13);
        assertFalse(isSiblingScenario3, "Expected not to be siblings.");

        boolean isSiblingScenario4 = tree.isSibling(14, 15);
        assertFalse(isSiblingScenario4, "Expected not to be siblings.");
    }
    
    
    @Test
    @DisplayName("Test isHalfSibling method - Edge Coverage")
    public void testIsHalfSiblingEdgeCoverage() {
    	
        boolean isHalfSiblingScenario1 = tree.isHalfSibling(12, 11);
        assertTrue(isHalfSiblingScenario1, "Expected to be half siblings.");

        boolean isHalfSiblingScenario2 = tree.isHalfSibling(10, 13);
        assertTrue(isHalfSiblingScenario2, "Expected to be half siblings.");

        boolean isHalfSiblingScenario3 = tree.isHalfSibling(12, 14);
        assertFalse(isHalfSiblingScenario3, "Expected not to be half siblings.");

        boolean isHalfSiblingScenario4 = tree.isHalfSibling(10, 13);
        assertTrue(isHalfSiblingScenario4, "Expected to be half siblings.");

        boolean isHalfSiblingScenario5 = tree.isHalfSibling(14, 15);
        assertFalse(isHalfSiblingScenario5, "Expected not to be half siblings.");
    }


}
