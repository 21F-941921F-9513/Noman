package dal;

import dto.PersonDTO;

public interface IFamilyTreeDAO {
	
	public PersonDTO getFather(Integer cnic);
	public PersonDTO getMother(Integer cnic);
}
