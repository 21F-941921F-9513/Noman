package dal;

import dto.PersonDTO;

public class FamilyTreeDAO implements IFamilyTreeDAO {
	
	@Override
	public PersonDTO getFather(Integer cnic) {
		// Original Database Queries
		return null;
	}
	
	@Override
	public PersonDTO getMother(Integer cnic) {
		// Original Database Queries
		return null;
	}
}
