package dto;

public class PersonDTO {
	private int id, cnic, fathersCnic, mothersCnic;
	private String name;
	
	public PersonDTO(int id, String name, int cnic, int fathersCnic, int mothersCnic) {
		this.id = id;
		this.name = name;
		this.cnic = cnic;
		this.fathersCnic = fathersCnic;
		this.mothersCnic = mothersCnic;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getCnic() {
		return cnic;
	}
	public void setCnic(int cnic) {
		this.cnic = cnic;
	}
	public int getFathersCnic() {
		return fathersCnic;
	}
	public void setFathersCnic(int fathersCnic) {
		this.fathersCnic = fathersCnic;
	}
	public int getMothersCnic() {
		return mothersCnic;
	}
	public void setMothersCnic(int mothersCnic) {
		this.mothersCnic = mothersCnic;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
